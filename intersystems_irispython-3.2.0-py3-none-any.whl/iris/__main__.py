import sys
import iris._PythonGateway

if len(sys.argv) >= 2 and sys.argv[1] == "PythonGateway":
    iris._PythonGateway._PythonGateway._main(sys.argv[2:])
else:
    print("Invalid Parameter")